package com.example.horadasperguntas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void startsobreActivity (View view){
        Intent sobreActivity = new Intent(this,ActivitySobre.class);
        startActivity(sobreActivity);
        finish();

    }
    public void startinfoActivity (View view){
        Intent infoActivity = new Intent(this,Info.class);
        startActivity(infoActivity);
        finish();
    }

}




