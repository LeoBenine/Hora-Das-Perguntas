package com.example.horadasperguntas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivitySobre extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_sobre);

            Button volta = (Button) findViewById(R.id.volta);

            volta.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent it = new Intent(ActivitySobre.this, MainActivity.class);
                    startActivity(it);
                    finish();

                }

                ;
            });
        }
    }



