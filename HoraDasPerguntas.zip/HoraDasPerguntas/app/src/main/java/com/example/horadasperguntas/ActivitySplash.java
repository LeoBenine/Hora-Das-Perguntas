package com.example.horadasperguntas;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Timer;
import java.util.TimerTask;

public class ActivitySplash extends AppCompatActivity {

    long Delay = 6000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Timer RunSplash = new Timer();
        TimerTask ShowSplash = new TimerTask() {
            @Override
            public void run() {

                finish();

                Intent intent =  new Intent(ActivitySplash.this, MainActivity.class);
                startActivity(intent);
            }
        };
        RunSplash.schedule(ShowSplash, Delay);
    }
}
